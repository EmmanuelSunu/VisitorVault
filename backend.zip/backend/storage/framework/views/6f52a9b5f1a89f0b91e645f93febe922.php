<?php echo e($slot); ?>

<?php /**PATH C:\Users\sever\Documents\code\other\VisitorVault\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>